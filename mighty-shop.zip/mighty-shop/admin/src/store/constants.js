export const SET_USER = "SET_USER";
export const LOGOUT = "LOGOUT";
export const AUTH_LOADING_ON = "AUTH_LOADING_ON";
export const AUTH_LOADING_OFF = "AUTH_LOADING_OFF";